#ifndef __LOCATION
#define __LOCATION
#include "sys.h"
int back_center(void);
void back_center_lap(void);
void star_go();
void go_home();
#endif




