void getup_red_1(void);
void getup_green_1(void);
void getup_bule_1(void);
void getdown_red_1(void);
void getdown_green_1(void);
void getdown_bule_1(void);
void get1(void);
void get2(void);
void get3();
void get4(void);
void choise_1(void);
void choise_2(void);


