#ifndef __WIFI_BASE
#define __WIFI_BASE
void inint_wifi(void);
void u3_printf(char* fmt, ...);



#endif




